/// This is a simple Rust program that prints "Hello, world!" to the console.
/// - It serves as a basic example of a Rust application structure.
/// - The main function is the entry point of the program.
fn main() { 
    println!("Hello, world!");
}
